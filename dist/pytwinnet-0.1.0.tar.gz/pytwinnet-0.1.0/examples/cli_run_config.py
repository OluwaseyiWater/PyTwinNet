# Quick helper: python -m pytwinnet.cli run configs/het_net_placement.yaml
from pytwinnet.cli.main import main

if __name__ == "__main__":
    main(["run", "configs/het_net_placement.yaml"])
