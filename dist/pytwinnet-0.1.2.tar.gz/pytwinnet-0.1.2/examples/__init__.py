"""
Example scripts for PyTwinNet.

You can run them as modules:
    python -m examples.basic_simulation
    python -m examples.ingestion_and_optimization
"""
