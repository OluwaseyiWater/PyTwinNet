"""CLI for config-driven experiments.

Usage:
    python -m pytwinnet.cli run path/to/config.yaml
"""
